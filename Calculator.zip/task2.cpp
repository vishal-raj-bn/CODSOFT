#include <iostream>

int main()
{
    double n1, n2;
    char operat;
    double result1;

    // Input two numbers
    std::cout << "Enter the 1st number: ";
    std::cin >> n1;

    std::cout << "Enter the 2nd number: ";
    std::cin >> n2;

    // Input the operation
    std::cout << "Enter the operation (+, -, *, /): ";
    std::cin >> operat;

    // Perform the chosen operation
    switch (operat)
    {
    case '+':
        result1 = n1 + n2;
        std::cout << "Result is: " << result1 << std::endl;
        break;
    case '-':
        result1 = n1 - n2;
        std::cout << "Result is: " << result1 << std::endl;
        break;
    case '*':
        result1 = n1 * n2;
        std::cout << "Result is: " << result1 << std::endl;
        break;
    case '/':
        if (n2 != 0)
        {
            result1 = n1 / n2;
            std::cout << "Result is: " << result1 << std::endl;
        }
        else
        {
            std::cout << "Error: Division by zero is not allowed." << std::endl;
        }
        break;
    default:
        std::cout << "Error: The operation is invalid." << std::endl;
        break;
    }

    return 0;
}
