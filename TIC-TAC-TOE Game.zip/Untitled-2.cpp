#include <iostream>
#include <vector>

using namespace std;

// Function to print the game board
void printBoard(const vector<vector<char>> &board)
{
    cout << "\n";
    for (const auto &row : board)
    {
        for (char cell : row)
        {
            cout << cell << " | ";
        }
        cout << "\n---------\n";
    }
    cout << "\n";
}

// Function to check if a player has won
bool checkWin(const vector<vector<char>> &board, char player)
{
    // Check rows and columns
    for (int i = 0; i < 3; ++i)
    {
        if ((board[i][0] == player && board[i][1] == player && board[i][2] == player) ||
            (board[0][i] == player && board[1][i] == player && board[2][i] == player))
        {
            return true;
        }
    }
    // Check diagonals
    if ((board[0][0] == player && board[1][1] == player && board[2][2] == player) ||
        (board[0][2] == player && board[1][1] == player && board[2][0] == player))
    {
        return true;
    }
    return false;
}

// Function to check if the board is full (draw)
bool checkDraw(const vector<vector<char>> &board)
{
    for (const auto &row : board)
    {
        for (char cell : row)
        {
            if (cell == ' ')
            {
                return false;
            }
        }
    }
    return true;
}

int main()
{
    char playnext;
    do
    {
        vector<vector<char>> board(3, vector<char>(3, ' '));
        char presentPlayer = 'X';
        bool gameover = false;

        cout << "Tic Tac Toe Game!!\n";

        while (!gameover)
        {
            printBoard(board);

            int row, col;
            cout << "Player " << presentPlayer << ", ENTER YOUR MOVE(row and column 1-3): ";
            cin >> row >> col;
            row--;
            col--; // Adjusting to 0-based index

            if (row < 0 || row >= 3 || col < 0 || col >= 3 || board[row][col] != ' ')
            {
                cout << "INVALID MOVE , TRY AGAIN\n";
                continue;
            }

            board[row][col] = presentPlayer;

            if (checkWin(board, presentPlayer))
            {
                printBoard(board);
                cout << "Hurray Player " << presentPlayer << " wins!!\n";
                gameover = true;
            }
            else if (checkDraw(board))
            {
                printBoard(board);
                cout << "It is a draw!!\n";
                gameover = true;
            }

            presentPlayer = (presentPlayer == 'X') ? 'O' : 'X';
        }

        cout << "Do you want to play again? (y/n): ";
        cin >> playnext;
    } while (playnext == 'y' || playnext == 'Y');

    return 0;
}
